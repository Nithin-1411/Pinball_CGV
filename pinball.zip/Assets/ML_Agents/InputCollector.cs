using UnityEngine;

public class InputCollector : MonoBehaviour
{
    public TicketAgent ticketAgent; // Reference to the TicketAgent script

    private float playerScore;     // Score of the player
    private int ballCollisions;    // Number of collisions during gameplay

    void Update()
    {
        // Example gameplay logic
        playerScore += Time.deltaTime * 10;  // Simulating score increment over time
        if (Input.GetKeyDown(KeyCode.C))     // Simulating collisions (e.g., when "C" is pressed)
        {
            ballCollisions++;
            Debug.Log("Ball Collided!");
        }

        // Update the agent with current gameplay data
        ticketAgent.playerScore = playerScore;
        ticketAgent.ballCollisions = ballCollisions;

        // Calculate tickets dynamically
        ticketAgent.CalculateTickets();
    }
}
