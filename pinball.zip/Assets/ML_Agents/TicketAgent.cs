using Unity.Barracuda;
using UnityEngine;

public class TicketAgent : MonoBehaviour
{
    public NNModel ticketModel;  // Drag your ONNX model file here in the Unity Inspector
    private IWorker worker;      // Worker to process the ML model

    public float playerScore;    // Player's score
    public int ballCollisions;   // Number of collisions with obstacles
    public int tickets;          // Predicted tickets

    void Start()
    {
        // Initialize the Barracuda worker for the ONNX model
        worker = ModelLoader.Load(ticketModel).CreateWorker();
    }

    public void CalculateTickets()
    {
        // Create input tensor with score and collisions
        Tensor inputTensor = new Tensor(1, 2);
        inputTensor[0, 0] = playerScore;       // First input: score
        inputTensor[0, 1] = ballCollisions;   // Second input: collisions

        // Execute the model
        worker.Execute(inputTensor);

        // Get model output (tickets)
        Tensor outputTensor = worker.PeekOutput(0);
        tickets = Mathf.Max(0, Mathf.RoundToInt(outputTensor[0])); // Ensure tickets are non-negative

        Debug.Log($"Tickets Awarded: {tickets}");

        // Cleanup tensors
        inputTensor.Dispose();
        outputTensor.Dispose();
    }

    void OnDestroy()
    {
        // Dispose of the worker when the object is destroyed
        worker.Dispose();
    }
}
