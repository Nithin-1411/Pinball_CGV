import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

# Define a simple neural network
class TicketModel(nn.Module):
    def __init__(self):
        super(TicketModel, self).__init__()
        self.fc1 = nn.Linear(2, 64)  # Input: [score, collisions]
        self.fc2 = nn.Linear(64, 32)
        self.fc3 = nn.Linear(32, 1)  # Output: tickets

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return torch.relu(self.fc3(x))  # Ensure tickets are non-negative

# Generate synthetic training data
def generate_data():
    scores = np.random.uniform(0, 10000, size=1000)  # Random scores
    collisions = np.random.randint(0, 50, size=1000) # Random collision counts
    tickets = scores / 100 - collisions * 0.5         # Example ticket logic
    tickets = np.clip(tickets, 0, None)              # Ensure no negative tickets
    X = np.column_stack((scores, collisions))
    y = tickets
    return torch.tensor(X, dtype=torch.float32), torch.tensor(y, dtype=torch.float32)

# Train the model
def train_model():
    X, y = generate_data()
    model = TicketModel()
    criterion = nn.MSELoss()  # Mean squared error for regression
    optimizer = optim.Adam(model.parameters(), lr=0.001)

    for epoch in range(500):  # Training loop
        optimizer.zero_grad()
        outputs = model(X)
        loss = criterion(outputs.squeeze(), y)
        loss.backward()
        optimizer.step()

       
    return model

# Save the trained model to ONNX format
def save_model(model, filename="ticket_model.onnx"):
    dummy_input = torch.tensor([[5000.0, 10.0]])  # Example input: [score, collisions]
    torch.onnx.export(
        model,
        dummy_input,
        filename,
        export_params=True,
        opset_version=11,
        input_names=["score", "collisions"],
        output_names=["tickets"]
    )
    print(f"Model saved as {filename}")

if __name__ == "__main__":
    model = train_model()
    save_model(model)
