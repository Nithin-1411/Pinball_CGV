using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoringObject : MonoBehaviour
{
    [Range(1,500)]
    public int IncrementValue;
}
