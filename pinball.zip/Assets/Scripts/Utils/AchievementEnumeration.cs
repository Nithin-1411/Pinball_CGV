public enum AchievementEnumeration
{
    None,
    GettingStarted,
    Ninja,
    GamblingExpert,
    GamblingNewbie,
    GamblingTycoon,
    Jackpot,
    OneOfAKind,
    PinballWizard,
    StraightFlush,
    Survivalist,
    TicketApprentice,
    TicketHoarder,
    TicketManiac,
    TicketMaster
}