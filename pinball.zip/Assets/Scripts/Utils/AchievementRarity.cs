public enum AchievementRarity
{
    Common,
    Rare,
    Legendary
}