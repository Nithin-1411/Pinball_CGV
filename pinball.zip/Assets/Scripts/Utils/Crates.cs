public enum Crates
{
    Rusty,
    Brass,
    Golden
}