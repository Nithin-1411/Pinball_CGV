public enum ItemEnumeration
{
    NoItem,
    Fireball,
    WaterDroplet,
    LuckyCharm,
    CurseOfAnubis,
    AngelWings,
    CameraFlip,
    ExtraBall,
    HealthBonus,
    PingPong,
    Rock,
    TennisBall,
    TicketPrize
}